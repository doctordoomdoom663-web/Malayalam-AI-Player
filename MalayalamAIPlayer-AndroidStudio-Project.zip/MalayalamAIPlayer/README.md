# Malayalam AI Player (Android starter project)

An Android Studio starter app for a local video player with external SRT subtitles and online AI translation to Malayalam.

## Current implementation
- Local video picker using Android Storage Access Framework
- Playback using AndroidX Media3 ExoPlayer
- Playback speed selector
- External SRT subtitle picker
- OpenAI-compatible Chat Completions API integration for subtitle translation
- Generated Malayalam SRT attached as a subtitle track

## Build an APK
1. Install the latest stable Android Studio on a computer.
2. Open this folder (`MalayalamAIPlayer`) in Android Studio.
3. Let Gradle sync and install any requested Android SDK 35 components.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio creates the debug APK under `app/build/outputs/apk/debug/`.

## Install on OnePlus Nord CE5
Transfer the generated APK to the phone, open it, and allow installation from that source when Android asks.

## AI translation setup
The app currently expects an OpenAI-compatible `POST /v1/chat/completions` endpoint. Enter:
- API URL, for example `https://api.openai.com/v1/chat/completions`
- API key
- Model name available to your account

AI translation requires internet and API usage may incur charges. The app sends subtitle dialogue to the provider. Do not share an APK containing a personal API key. For a public release, move the API key to a secure backend you control.

## Important limitations of this starter
This is source code, not a compiled APK. It has not been built or tested on a physical device in this environment. Before public release, add robust SRT parsing/batching, API error handling, keychain/secure backend handling, translated subtitle export, audio track selection, picture-in-picture, background playback service, and device testing. The initial translator is a starter integration and may need adjustment for providers with nonstandard API formats.
