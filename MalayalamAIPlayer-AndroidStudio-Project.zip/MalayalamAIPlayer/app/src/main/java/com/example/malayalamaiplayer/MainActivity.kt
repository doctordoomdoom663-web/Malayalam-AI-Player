package com.example.malayalamaiplayer

import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

@UnstableApi
class MainActivity : ComponentActivity() {
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var status: TextView
    private lateinit var apiUrl: EditText
    private lateinit var apiKey: EditText
    private lateinit var model: EditText
    private var videoUri: Uri? = null
    private var subtitleText: String? = null
    private var translatedFile: File? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val http = OkHttpClient.Builder()
        .callTimeout(180, TimeUnit.SECONDS).build()

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            videoUri = uri
            play(uri, null)
            status.text = "Video loaded. Add an SRT subtitle or use an embedded subtitle track."
        }
    }
    private val pickSubtitle = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            contentResolver.openInputStream(uri)?.bufferedReader()?.use { subtitleText = it.readText() }
            status.text = "Subtitle loaded. Ready to translate."
            if (videoUri != null) play(videoUri!!, uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        player = ExoPlayer.Builder(this).build()
        playerView.player = player
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 20, 18, 24)
            setBackgroundColor(0xFF090F1C.toInt())
        }
        scroll.addView(page)
        setContentView(scroll)

        page.addView(TextView(this).apply {
            text = "Malayalam AI Player"
            textSize = 25f; setTextColor(0xFFFFFFFF.toInt()); gravity = Gravity.CENTER_VERTICAL
        })
        page.addView(TextView(this).apply {
            text = "MX Player-style playback • AI Malayalam subtitles"
            textSize = 13f; setTextColor(0xFF9CA3AF.toInt())
            setPadding(0, 4, 0, 16)
        })

        playerView = PlayerView(this).apply {
            useController = true
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            setBackgroundColor(0xFF000000.toInt())
        }
        page.addView(playerView, LinearLayout.LayoutParams(-1, dp(220)))

        val openVideo = button("Open video")
        openVideo.setOnClickListener { pickVideo.launch(arrayOf("video/*")) }
        page.addView(openVideo)

        val openSub = button("Load SRT subtitle")
        openSub.setOnClickListener { pickSubtitle.launch(arrayOf("application/x-subrip", "text/plain", "*/*")) }
        page.addView(openSub)

        page.addView(label("Playback speed"))
        val speeds = Spinner(this)
        val speedValues = listOf("0.5x", "0.75x", "1.0x", "1.25x", "1.5x", "2.0x")
        speeds.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, speedValues)
        speeds.setSelection(2)
        speeds.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                player?.playbackParameters = PlaybackParameters(speedValues[position].dropLast(1).toFloat())
            }
        }
        page.addView(speeds)

        page.addView(label("AI translation service (OpenAI-compatible Chat Completions API)"))
        apiUrl = edit("API URL", "https://api.openai.com/v1/chat/completions")
        apiKey = edit("API key", "")
        apiKey.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        model = edit("Model name", "gpt-4o-mini")
        page.addView(apiUrl); page.addView(apiKey); page.addView(model)

        val translate = button("Translate subtitles to Malayalam")
        translate.setOnClickListener { translateSubtitle() }
        page.addView(translate)

        status = TextView(this).apply {
            text = "Choose a video to begin."
            setTextColor(0xFFBAE6FD.toInt()); textSize = 14f
            setPadding(0, 14, 0, 8)
        }
        page.addView(status)
        page.addView(TextView(this).apply {
            text = "Note: AI translation needs internet access and an API key. This starter app sends subtitle text to the translation provider you configure. Do not use a personal production API key in an APK you share publicly."
            textSize = 12f; setTextColor(0xFF9CA3AF.toInt()); setPadding(0, 8, 0, 8)
        })
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text; textSize = 14f; setTextColor(0xFFE5E7EB.toInt())
        setPadding(0, 14, 0, 6)
    }
    private fun edit(hintText: String, value: String) = EditText(this).apply {
        hint = hintText; setText(value); setSingleLine(true)
        textSize = 14f; setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFF9CA3AF.toInt())
        setPadding(dp(12), dp(8), dp(12), dp(8))
    }
    private fun button(textValue: String) = Button(this).apply {
        text = textValue; isAllCaps = false
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun play(video: Uri, subtitle: Uri?) {
        val builder = MediaItem.Builder().setUri(video)
        if (subtitle != null) {
            val sub = MediaItem.SubtitleConfiguration.Builder(subtitle)
                .setMimeType(MimeTypes.APPLICATION_SUBRIP)
                .setLanguage("en")
                .setSelectionFlags(androidx.media3.common.C.SELECTION_FLAG_DEFAULT)
                .build()
            builder.setSubtitleConfigurations(listOf(sub))
        }
        player?.setMediaItem(builder.build())
        player?.prepare()
        player?.playWhenReady = true
    }

    private fun translateSubtitle() {
        val source = subtitleText
        if (source.isNullOrBlank()) {
            status.text = "Load an .srt subtitle file first."
            return
        }
        val key = apiKey.text.toString().trim()
        val url = apiUrl.text.toString().trim()
        val modelName = model.text.toString().trim()
        if (key.isBlank() || url.isBlank() || modelName.isBlank()) {
            status.text = "Enter your translation API URL, API key and model."
            return
        }
        status.text = "Translating subtitle… keep the app open."
        val translateButtonMessage = "Translation runs online. Large subtitle files may take a little time."
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) { translateSrt(source, key, url, modelName) }
                val out = File(cacheDir, "subtitle_ml.srt")
                out.writeText(result)
                translatedFile = out
                status.text = "Malayalam subtitle translated and saved in app cache. Original SRT remains unchanged."
                // Attach the generated SRT as a subtitle track to the currently playing video.
                val v = videoUri
                if (v != null) {
                    val subUri = Uri.fromFile(out)
                    val cfg = MediaItem.SubtitleConfiguration.Builder(subUri)
                        .setMimeType(MimeTypes.APPLICATION_SUBRIP)
                        .setLanguage("ml")
                        .setLabel("Malayalam (AI)")
                        .setSelectionFlags(androidx.media3.common.C.SELECTION_FLAG_DEFAULT)
                        .build()
                    player?.setMediaItem(MediaItem.Builder().setUri(v).setSubtitleConfigurations(listOf(cfg)).build())
                    player?.prepare()
                    player?.playWhenReady = true
                }
            } catch (e: Exception) {
                status.text = "Translation failed: ${e.message ?: "Check network and API settings."}"
            }
        }
    }

    private fun translateSrt(srt: String, key: String, url: String, modelName: String): String {
        // Preserve cue numbers and timestamps. Translate only subtitle text, in small batches.
        val blocks = srt.replace("\r\n", "\n").trim().split(Regex("\n\\s*\n"))
        val output = mutableListOf<String>()
        for (batch in blocks.chunked(18)) {
            val prompt = """
                Translate the subtitle dialogue below into natural, conversational Malayalam.
                Preserve meaning, emotion, names and tone. Do not translate cue numbers or timestamps.
                Return only the translated dialogue lines in the same order, one cue per line.
                Input cues:
                ${batch.mapIndexed { i, block ->
                    val lines = block.lines()
                    val textLines = lines.dropWhile { it.matches(Regex("\\d+")) || it.contains("-->") }
                    "${i + 1}. ${textLines.joinToString(" ")}"
                }.joinToString("\n")}
            """.trimIndent()
            val body = JSONObject()
                .put("model", modelName)
                .put("temperature", 0.2)
                .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
            val request = Request.Builder().url(url)
                .addHeader("Authorization", "Bearer $key")
                .addHeader("Content-Type", "application/json")
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()
            http.newCall(request).execute().use { response ->
                if (!response.isSuccessful) throw IllegalStateException("API HTTP ${response.code}: ${response.body?.string()?.take(300)}")
                val json = JSONObject(response.body?.string() ?: error("Empty API response"))
                val content = json.getJSONArray("choices").getJSONObject(0)
                    .getJSONObject("message").getString("content")
                val translatedLines = content.lines().map {
                    it.trim().replace(Regex("^\\s*\\d+[.)、:-]?\\s*"), "")
                }.filter { it.isNotBlank() }
                batch.forEachIndexed { index, block ->
                    val lines = block.lines()
                    val header = lines.takeWhile { it.matches(Regex("\\d+")) || it.contains("-->") }
                    val textLines = lines.drop(header.size)
                    val translated = translatedLines.getOrNull(index) ?: textLines.joinToString(" ")
                    output.add((header + translated).joinToString("\n"))
                }
            }
        }
        return output.joinToString("\n\n")
    }

    override fun onStop() {
        super.onStop()
        player?.pause()
    }
    override fun onDestroy() {
        player?.release()
        player = null
        scope.cancel()
        super.onDestroy()
    }
}
